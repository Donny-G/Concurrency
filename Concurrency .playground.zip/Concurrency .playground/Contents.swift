import UIKit

var array: [Int] = []

let concurrentQueue = DispatchQueue(label: "concurent", attributes: .concurrent)
let globalQueue = DispatchQueue.global()

//mutex
let lock = NSLock()

func writeAndPrintWithMutex(tag: Int) {
    lock.lock()
    print(tag)
    print(array)
    array.append(Int.random(in: 0 ... 67))
    print(array)
    lock.unlock()
}

func startTaskWithMutex(nValue: Int) {
    let group = DispatchGroup()
    for n in 1 ... nValue {
        concurrentQueue.async(group: group) {
            writeAndPrintWithMutex(tag: n)
        }
    }
    
    group.notify(queue: .main) {
        print("all work completed")
    }
}

//semaphore
let semaphore = DispatchSemaphore(value: 1)
func writeAndPrintWithSemaphore(tag: Int) {
    semaphore.wait()
    print(tag)
    print(array)
    array.append(Int.random(in: 0 ... 67))
    print(array)
    semaphore.signal()
}

func startTaskWithSemaphore(nValue: Int) {
    let group = DispatchGroup()
    for n in 1 ... nValue {
        concurrentQueue.async {
            writeAndPrintWithSemaphore(tag: n)
        }
    }
    
    group.notify(queue: .main) {
        print("all work completed")
    }
}

//barrier
func startTaskWithBarrier(nValue: Int) {
    let group = DispatchGroup()
    var _array: [Int] {
        get {
            var temp: [Int] = []
            concurrentQueue.sync {
                temp = array
            }
            return temp
        }
        set {
            concurrentQueue.async(flags: .barrier) {
                array = newValue
            }
        }
    }
    
    for n in 1 ... nValue {
        print(n)
        print(_array)
        _array.append(Int.random(in: 0 ... 67))
        print(_array)
    }
    
    group.notify(queue: .main) {
        print("all work completed")
    }
}

//dispatch group and item
let serialQueue = DispatchQueue(label: "serial")
func startTaskWithDispatchGroupAndItem(nValue: Int) {
    let group = DispatchGroup()
    for n in 1 ... nValue {
        let workItem = DispatchWorkItem {
            print(n)
            print(array)
            array.append(Int.random(in: 0 ... 67))
            print(array)
        }
        serialQueue.async(group: group, execute: workItem)
    }
    
    group.notify(queue: .main) {
        print("all work completed")
    }
}

//dispatch group and item 2
func startTaskWithDispatchGroupAndItem2(nValue: Int) {
    
    for n in 1 ... nValue {
        let group = DispatchGroup()
        let workItem = DispatchWorkItem {
            print(n)
            print(array)
            array.append(Int.random(in: 0 ... 67))
            print(array)
            group.leave()
        }
        group.enter()
        concurrentQueue.async(execute: workItem)
        group.wait()
    }
    print("all work completed")
}

//operations

class AsyncOperation: Operation {
    override var isAsynchronous: Bool {
        return true
    }
    
    private var _isExecuting: Bool = false
    override private(set) var isExecuting: Bool {
        get {
            return concurrentQueue.sync { () -> Bool in
                return _isExecuting
            }
        }
        set {
            willChangeValue(forKey: "isExectuing")
            concurrentQueue.sync(flags: [.barrier]) {
                _isExecuting = newValue
            }
            didChangeValue(forKey: "isExecuting")
        }
    }
    
    private var _isFinished: Bool = false
    override private(set) var isFinished: Bool {
        get {
            return concurrentQueue.sync { () -> Bool in
                return _isFinished
            }
        }
        set {
            willChangeValue(forKey: "isFinished")
            concurrentQueue.sync(flags: [.barrier]) {
                _isFinished = newValue
            }
            didChangeValue(forKey: "isFinished")
        }
    }
    
    override func start() {
        print(array)
        array.append(Int.random(in: 0 ... 67))
        print(array)
        isFinished = false
        isExecuting = true
        main()
    }
    
    override func main() {
        self.finish()
    }
    func finish() {
        isExecuting = false
        isFinished = true
    }
}

func startTaskWithOperation(nValue: Int) {
    
    for n in 1 ... nValue {
        let operation = AsyncOperation()
        let queue = OperationQueue()
        queue.addOperations([operation], waitUntilFinished: true)
    }
    print("all work completed")
}

//startTaskWithMutex(nValue: 4)
//startTaskWithSemaphore(nValue: 4)
//startTaskWithBarrier(nValue: 4)
//startTaskWithDispatchGroupAndItem(nValue: 4)
//startTaskWithDispatchGroupAndItem2(nValue: 4)
//startTaskWithOperation(nValue: 4)




